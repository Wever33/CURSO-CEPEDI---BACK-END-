dinheiro_na_carteira = float(input("Dinheiro na carteira (R$): "))

VALOR_DOLAR = 5.50

valor_convertido = dinheiro_na_carteira/VALOR_DOLAR 

print(f"Valor em reais: R$ {dinheiro_na_carteira}\nValor em dólar: US$ {valor_convertido:.2f}")