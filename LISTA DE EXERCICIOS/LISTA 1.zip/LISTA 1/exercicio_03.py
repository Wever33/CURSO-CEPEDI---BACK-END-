largura = float(input("Largura da parede: "))
altura = float(input("Altura da parede: "))

area_pintada = largura*altura
LITRO_DE_TINTA = 2 

print(f"A quantidade de tinta necessária para pintar esse parede de {area_pintada} m é = {area_pintada/LITRO_DE_TINTA} L") 