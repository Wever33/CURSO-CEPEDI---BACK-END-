nota_1 = float(input("Nota 1: "))
nota_2 = float(input("Nota 2: "))

media = (nota_1+nota_2)/2

print(f"Média entre as notas {nota_1} e {nota_2} = {media}")
